'''
MilkyWay@home Python Package (mwahpy) v1.0
Copyright Tom Donlon 2020, RPI

See provided readme and documentation for information
or reach out to me on github
user: thomasdonlon
'''

import mwahpy_plotting as mplt
